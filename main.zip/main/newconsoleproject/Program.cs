﻿using System;

namespace newconsoleproject
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("isminizi girin:");
            string name = Console.ReadLine();
            Console.WriteLine("soyismnizi girin:");
            string surname = Console.ReadLine();
            Console.WriteLine("isim soyisim={0} {1}",name,surname);//0 a karşlık gelen stringi ve 1 e karşılık gelen stringi alıp ekrana basar.

        }
    }
}
