﻿using System;

namespace operatorler
{
    class Program
    {
        static void Main(string[] args)
        {
            //atama ve işlemli atama
            int x = 3;
            int y = 3;
            y = y + 2;
            Console.WriteLine(y);
            y += 2;
            Console.WriteLine(y);
            y /= 1;
            Console.WriteLine(y);
            y *= 2;
            Console.WriteLine(x);
            //mantıksal oparotörler
            bool isSuccess = true;
            bool isComleted = false;
            if (isSuccess && isComleted)
                Console.WriteLine("perfect!");
            if (isSuccess || isComleted)
                Console.WriteLine("Great!");
            if (isSuccess && !isComleted)
                Console.WriteLine("Fine!");
            Console.WriteLine(sonuc);
            //ilişkisel operatörler
            int a = 3;
            int b = 4;
            bool sonuc = a < b;
            Console.WriteLine(sonuc);
            sonuc = a > b;
            Console.WriteLine(sonuc);
            sonuc = a >= b;
            Console.WriteLine(sonuc);
            sonuc = a <= b;
            Console.WriteLine(sonuc);
            sonuc = a == b;
            Console.WriteLine(sonuc);
            sonuc = a != b;
            Console.WriteLine(sonuc);
            Console.WriteLine("******Aritmetik operatörler*****");
            //*,/,+,-
            int sayı1 = 10;
            int sayı2 = 5;
            int sonuc1 = sayı1 / sayı2;
            Console.WriteLine(sonuc1);
            sonuc1 = sayı1 * sayı2;
            Console.WriteLine(sonuc1);
            sonuc1 = sayı1 + sayı2;
            Console.WriteLine(sonuc1);
            sonuc1 = sayı1++;
            Console.WriteLine(sayı2);
            //%:mod alır
            int sonuc2 = 20 % 3;
            Console.WriteLine(sonuc2);
           





































        }
    }
}
