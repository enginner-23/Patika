﻿using System;
using System.Collections.Generic;

namespace c_ödev1
{
    class Program
    {
        static void Main(string[] args)
        {
           // birinci();
            //ikinci_soru();
            ücüncüsoru();
            //sonsoru();
        }
        static void birinci()
        {
            Console.WriteLine("Pozitif bir sayı giriniz: ");
            int n = int.Parse(Console.ReadLine());
            List<int> sayılar = new List<int>(); //n tane sayı istediği için list yaptık.
            for (int i = 1; i <= n; i++)
            {
                Console.WriteLine("{0}. sayıyı giriniz", i);
                sayılar.Add(int.Parse(Console.ReadLine()));
            }
            Console.WriteLine("çift sayılar");
            foreach (var item in sayılar)
            {
                if (item % 2 == 0)
                {
                    Console.Write(item + " ");
                }

            }
        }
        static void ikinci_soru() {
            Console.WriteLine("bir sayı girin");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("Farklı Pozitif bir sayı giriniz: ");
            int m = int.Parse(Console.ReadLine());
            List<int> sayılar = new List<int>();//n tane sayı girmek için.
            for(int i=1; i<=n; i++)
            {
                Console.WriteLine("{0}.sayıyı giriniz", i);
                sayılar.Add(int.Parse(Console.ReadLine()));

            }
            Console.WriteLine("m'e eşit ve bölünen sayılar");
            foreach(var item in sayılar)
            {
                if( item % m == 0)
                {
                    Console.Write(item + " ");
                }
            }
        

        }
        static void ücüncüsoru()
        {
            Console.WriteLine("bir sayı girin");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("kelime girin");
            string kelime = Console.ReadLine();
            List<string> kelimeler = new List<string>();//n adet kelime girmek için
            for (int i = 1; i <= n; i++)
            {
                Console.WriteLine("{0}. kelimeyi giriniz", i);
                kelimeler.Add(Console.ReadLine());
            }

            kelimeler.Reverse();
            foreach (var item in kelimeler)
            {
                Console.WriteLine(item);
            }
        }

        static void sonsoru()
        {

            Console.WriteLine("bir cümle girin");
            string cumle = Console.ReadLine();
            string[] kelimeler = cumle.Split(" ");
            int toplamKelime = kelimeler.Length;
            int toplamHarf = 0;
            foreach (var item in kelimeler)
            {
                toplamHarf += item.Length;
            }

            Console.WriteLine("Toplam kelime: {0}", toplamKelime);
            Console.WriteLine("Toplam harf: {0}", toplamHarf);




        }
    }
    
   
        
          


        }
    
